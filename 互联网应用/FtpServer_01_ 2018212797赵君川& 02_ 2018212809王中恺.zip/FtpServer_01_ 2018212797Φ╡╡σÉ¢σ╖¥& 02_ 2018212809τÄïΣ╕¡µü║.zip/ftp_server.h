#ifndef FTP_SERVER_H
#define FTP_SERVER_H

#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <pwd.h>
#include <netinet/in.h>
#include <time.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <unistd.h>


#define LENGTH 1024
#define FILE_BUF_LEN 2048
#define MAX_SPEED 500 //KBps
#define MIN_SPEED 50 //KBps

typedef struct client_info{
    int traffic;//总流量
    char is_login;//是否登录
    char user_name[258];
    int authority;
    int client_fd;//客户端的fd
    int active_port;//主动模式的port
    int passive_port;
}Client_Info;

#endif 