#include "ftp_server.h"


Client_Info client_info;//客户端信息
char * client_ip = NULL;//记录客户端ip 字符串
char *username_table[] = {"u1", "u2", "u3"};
char *password_table[] = {"111111", "111111", "123456"};
int authority_table[] = {0, 1, 2};
char src_file_name[LENGTH];
int pasv_on = 0;

int server_pasv_port;
char * server_pasv_ip = NULL;
int pasv_data_connection;
int client_fd_pasv;
/*
* 得到通用的port
* */
int generate_common_socket(int port){
    int target_socket;
    if((target_socket = socket(AF_INET, SOCK_STREAM, 0)) < 0){
        fprintf(stderr, "can't get socket\n");
        return -1;
    }
    int reuse = 1;
    //重用端口
    setsockopt(target_socket, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    struct sockaddr_in s_addr;
    // 初始化为0
    bzero(&s_addr,sizeof(struct sockaddr_in));
    s_addr.sin_family = AF_INET;
    s_addr.sin_port = htons (port);
    s_addr.sin_addr.s_addr = htonl(INADDR_ANY);//本地地址
    // bind port
    if(bind(target_socket,(struct sockaddr*) &s_addr, sizeof(s_addr)) < 0){
        fprintf(stderr, "can't bind addreess\n");
        return -1;
    }
    return target_socket;
}
void user(char * arg);
void pass(char * arg);
void syst(char * arg);
void port(char * arg);
void list(char * arg);
void pwd(char * arg);
void cwd(char * arg);
void mkd(char * arg);
void rnfr(char * arg);
void rnto(char * arg);
void retr(char * arg);
void stor(char * arg);
void dele(char * arg);
void pasv(char * arg);
void quit(char * arg);

int generate_common_socket(int port);
void analyze_permit(int perm, char *str_perm);
void speed_limit_upload(char * arg, int fd_socket);
void speed_limit_download(char * arg, int fd_socket, int fd);


int main()
{
    //绑定服务器的端口
	int socket_fd = generate_common_socket(21);
    if(socket_fd <0){//出错
        exit(-1);
    }
    //服务器端监听
    if(listen(socket_fd, 5) < 0)
    {
        perror("Listen Error!\n");
        return -1;
    }
    struct sockaddr_in ip_addr;
    int length = sizeof(struct sockaddr_in);
    //监听,得到客户端socket 
    int client_fd;
    if((client_fd = accept(socket_fd, (struct sockaddr*) &ip_addr,&length))< 0)
    {
        perror( "client connect failed!!!\n");
        exit(-1);
    } 
    //服务器进行处理
    char recv_msg[LENGTH];//存放发送和接受的客户端消息
    //初始化客户端信息
    client_info.traffic = 0;
    client_info.is_login = -1;
    client_info.client_fd = client_fd;
    //发送起始消息
    bzero(&recv_msg, LENGTH);
    sprintf(recv_msg, "220 start ftp server connect!\n");
    send(client_fd, recv_msg, strlen(recv_msg),0);
    //开始循环读取消息
    int recv_size;
    bzero(&recv_msg, LENGTH);
    while((recv_size = recv(client_fd, recv_msg,LENGTH,0))> 0){
        if(recv_size> LENGTH || recv_size < 0){
            fprintf(stderr,"receive message error\n");
            continue;
        }
        printf("cmd = %s\n",recv_msg);
        char command[100];
        char arg[LENGTH];
        sscanf(recv_msg, "%s %s",command, arg);
        if(strcmp("USER", command) == 0){
            user(arg);
        }else if(strcmp("PASS", command) == 0){
            pass(arg);
        }else if(strcmp("SYST", command) == 0){
            syst(arg);
        }else if(strcmp("LIST", command) == 0){
            list(arg);
        }else if(strcmp("PORT", command) == 0){
            port(arg);
        }else if(strcmp("PWD", command) == 0){
            pwd(arg);
        }else if(strcmp("MKD", command) == 0){
            mkd(arg);
        }
        else if(strcmp("CWD", command) == 0){
            cwd(arg);
        }
        else if(strcmp("RNFR", command) == 0){
            rnfr(arg);
        }
        else if(strcmp("RNTO", command) == 0){
            rnto(arg);
        }
        else if(strcmp("PASV", command) == 0) {
        	pasv(arg);
        }
        else if(strcmp("RETR", command) == 0){
        	if(client_info.authority == 2) {
        		printf("%s is not allowed to download files\n", client_info.user_name);
            	char *send_msg = "502 Command not implemented.(no authrority)\n";
            	send(client_info.client_fd,send_msg, strlen(send_msg),0);
        	}
        	else {
        		retr(arg);
        	}
        }
        else if(strcmp("STOR", command) == 0){
            stor(arg);
        }
        else if(strcmp("DELE", command) == 0){
        	if(client_info.authority == 2) {
        		printf("%s is not allowed to delete\n", client_info.user_name);
            	char *send_msg = "502 Command not implemented.(no authrority)\n";
            	send(client_info.client_fd,send_msg, strlen(send_msg),0);
        	}
        	else {
        		dele(arg);
        	}
        }
        else if(strcmp("QUIT", command) == 0){
            quit(arg);
        }
        else{
            printf("%s ,I don't know what is this command\n", recv_msg);
            char *send_msg = "500 Unknown command\n";
            send(client_info.client_fd,send_msg, strlen(send_msg),0);
        }
        bzero(&recv_msg, LENGTH);
    }
    close(client_fd);
    fprintf(stdin,"see you agin\n");
	return 0;
}
//user command
void pasv(char * arg)
{
	pasv_on = 1;
	if(client_info.is_login != 1){
        char *send_msg = "530 no login\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }else{
        int h1,h2,ip1,ip2,ip3,ip4;
        ip1 = 127;
        ip2 = 0;
        ip3 = 0;
        ip4 = 1;
        srand((unsigned)time(NULL));
        server_pasv_port = (rand() % (65335 - 1025)) + 1025;

	    pasv_data_connection = generate_common_socket(server_pasv_port);
	    if(listen(pasv_data_connection, 10) < 0)
	    {
	        perror("Listen Error!\n");
	        return -1;
	    }
	    // printf("%d\n", pasv_data_connection);

        h1 = server_pasv_port/256;
        h2 = server_pasv_port%256;
        //解析port和客户端ip
        server_pasv_ip = malloc(sizeof(char)*LENGTH);
        sprintf(server_pasv_ip,"%d.%d.%d.%d",ip1,ip2,ip3,ip4);
        char *server_address = malloc(sizeof(char)*LENGTH);
        sprintf(server_address,"(%d,%d,%d,%d,%d,%d).\r\n",ip1,ip2,ip3,ip4,h1,h2);
        char *send_hint = "227 Entering Passive Mode ";
        char *send_msg = malloc(sizeof(char)*LENGTH);
        sprintf(send_msg, "%s%s", send_hint, server_address);
        char* p = strchr(send_msg, '.');
	    while(p != NULL){
	        *p = ',';
	        p = strchr(p, '.');
	    }
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }
}
void quit(char * arg)
{
    char *send_msg = "221 see you again.\n";
    send(client_info.client_fd,send_msg, strlen(send_msg),0);
}
void user(char * arg)
{
    int i;
    int count = sizeof(username_table)/sizeof(char*);
    for(i =0;i< count;i++){
        if(!strcmp(arg,username_table[i])){
        	client_info.authority = authority_table[i];
            break;
        }
    }
    if(i >= count){//不匹配
        char *send_msg = "530 name error!\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }else{
        client_info.is_login =0;
        strncpy(client_info.user_name, arg,strlen(arg));
        printf("user authority: %d\n", client_info.authority);
        char *send_msg = "331 next input password\n";
        send(client_info.client_fd, send_msg, strlen(send_msg), 0);
    }
}
void pass(char * arg){
    int i;
    int count = sizeof(username_table)/sizeof(char*);
    for(i =0;i< count;i++){
        if(!strcmp(arg,password_table[i]) && !strcmp(username_table[i], client_info.user_name)){
            break;
        }
    }
    if(i >= count){//不匹配
        char *send_msg = "500 password error!\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }else{
        client_info.is_login = 1;
        char *send_msg = "230 login success!\n";//登录成功
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }
}
void syst(char * arg){
    if(client_info.is_login != 1){
        char *send_msg = "530 no login\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }else{
        char *send_msg = "215 Linux\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }
}
void port(char * arg){
	pasv_on = 0;
    if(client_info.is_login != 1){
        char *send_msg = "530 no login\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }else{
        int h1,h2,ip1,ip2,ip3,ip4;
        //解析port和客户端ip
        sscanf(arg,"%d,%d,%d,%d,%d,%d",&ip1,&ip2,&ip3,&ip4,&h1,&h2);
        client_ip = malloc(sizeof(char)*LENGTH);
        sprintf(client_ip,"%d.%d.%d.%d",ip1,ip2,ip3,ip4);
        client_info.active_port = h1*256+h2;//计算port
        char *send_msg = "200 server get the port\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }
}
//解析权限
void analyze_permit(int perm, char *str_perm)
{
    int curperm = 0;
    int flag = 0;
    int read, write, exec;

    //权限
    char fbuff[3];
    read = write = exec = 0;

    int i;
    for(i = 6; i>=0; i-=3){
        /* Explode permissions of user, group, others; starting with users */
        curperm = ((perm & ALLPERMS) >> i ) & 0x7;

        memset(fbuff,0,3);
        /* Check rwx flags for each*/
        read = (curperm >> 2) & 0x1;
        write = (curperm >> 1) & 0x1;
        exec = (curperm >> 0) & 0x1;

        sprintf(fbuff,"%c%c%c",read?'r':'-' ,write?'w':'-', exec?'x':'-');
        strcat(str_perm,fbuff);

    }
}
void list(char * arg){
    if(client_info.is_login != 1){
        char *send_msg = "530 no login\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }else{
        //备份路径
        char cur_path[LENGTH], old_path[LENGTH];
        memset(old_path,0,LENGTH);
        memset(cur_path,0,LENGTH);
        //当前路径
        getcwd(old_path,LENGTH);
        //拿到新的路径
        if(arg[0]!='-' && strlen(arg)>0){
            chdir(arg);
        }
        getcwd(cur_path,LENGTH);
        //打开路径
        DIR *dir = opendir(cur_path);
        //cd的路径有问题
        if(NULL == dir){
            char *send_msg = "550 open directory error\n";
            send(client_info.client_fd,send_msg, strlen(send_msg),0);
            return;
        }
        //默认主动模式
        printf("Active Mode on\n");
        //创建数据通道
        int data_channel_fd = generate_common_socket(20);
        //客户端的地址
        struct sockaddr_in client_addr;
        //设置客户端地址
        memset(&client_addr, 0, sizeof(client_addr));
        client_addr.sin_family = AF_INET;
        client_addr.sin_port = htons(client_info.active_port);
        client_addr.sin_addr.s_addr = htonl(INADDR_ANY);
        //主动去连接客户端
        if(connect(data_channel_fd, (struct sockaddr *)&client_addr, sizeof(struct sockaddr_in)) < 0 )
        {
            perror("connect client fail\n");
            char *send_msg = "550 server connect client fail\n";
            send(client_info.client_fd,send_msg, strlen(send_msg),0);
            return;
        }
        printf("Connect client %s on TCP Port %d\n",client_ip,client_info.active_port); 
        //响应   
        char *send_msg = "150 connect client to use data channel\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
        printf("%s\t start execute LIST\n", client_info.user_name);
        //传输list的数据
        struct dirent *entry;
        struct stat statbuf;
        struct tm *time;
        char timebuff[LENGTH], current_dir[LENGTH];
        time_t rawtime;
        while((entry=readdir(dir))!=NULL){
            //拿到当前文件信息
            stat(entry->d_name,&statbuf);
            char *permit_str = malloc(9);
            memset(permit_str,0,9);
            //得到时间
            rawtime = statbuf.st_mtime;
            time = localtime(&rawtime);
            strftime(timebuff,80,"%b %d %H:%M",time);
            analyze_permit((statbuf.st_mode & ALLPERMS), permit_str);
            char list_msg[LENGTH];
            memset(&list_msg,0,LENGTH);
            if (client_info.authority==2) {
            	sprintf(list_msg,"%8d %s %s\r\n",
                    statbuf.st_size,
                    timebuff,
                    entry->d_name);
            }
            else {
            	sprintf(list_msg,"%c%s %5d %4d %4d %8d %s %s\r\n",(entry->d_type==DT_DIR)?'d':'-',
                    permit_str,statbuf.st_nlink,
                    statbuf.st_uid,
                    statbuf.st_gid,
                    statbuf.st_size,
                    timebuff,
                    entry->d_name);
            }
            send(data_channel_fd,list_msg, strlen(list_msg),0);
        }
        //list结束
        send_msg = "226 directory send finish\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
        close(data_channel_fd);
        printf("%s\t  execute LIST finish\n", client_info.user_name);
        closedir(dir);//关闭文件夹
        chdir(old_path);//回到初始路径
    }
}
void pwd(char * arg){
    if(client_info.is_login != 1){
        char *send_msg = "530 no login\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }else{
        char cwd[LENGTH];
        char msg[LENGTH];
        bzero(msg, LENGTH);
        if(NULL != getcwd(cwd,LENGTH)){
            printf("%s start run PWD\n", client_info.user_name);
            sprintf(msg,"257 \" %s \"\n", cwd);
            send(client_info.client_fd,msg, strlen(msg),0);
            printf("%s run PWD finish\n", client_info.user_name);
        }else{
           char *send_msg = "550 pwd run fail\n";
            send(client_info.client_fd,send_msg, strlen(send_msg),0);
        }
    }
}
void cwd(char * arg){
    if(client_info.is_login != 1){
        char *send_msg = "530 no login\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }else{
        printf("%s  start run cwd\n", client_info.user_name);
        if(0 == chdir(arg) ){
            char *send_msg = "250 directory changed ok\n";
            send(client_info.client_fd,send_msg, strlen(send_msg),0);
        }else{
            char *send_msg = "550 directory changed fail.\n";
            send(client_info.client_fd,send_msg, strlen(send_msg),0);
        }
        printf("%s  run cwd finish\n", client_info.user_name);
    }
}
void mkd(char * arg){
    if(client_info.is_login != 1){
        char *send_msg = "530 no login\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }else{
        char cwd[LENGTH];
        char msg[LENGTH];
        memset(cwd,0,LENGTH);
        memset(msg,0,LENGTH);
        //当前路径
        getcwd(cwd,LENGTH);
        printf("%s  start run mkdir\n", client_info.user_name);
        //如果是绝对路径
        if('/' == arg[0]){
            if(mkdir(arg,S_IRWXU)==0){
                sprintf(msg, "257 \"%s\" new directory create OK\n",arg);
                send(client_info.client_fd,msg, strlen(msg),0);
            }else{
                char *send_msg = "550 create directory fail\n";
                send(client_info.client_fd,send_msg, strlen(send_msg),0);
            }
        }
        else{//如果是相对路径
            if(mkdir(arg,S_IRWXU)==0){
                sprintf(msg,"257 \"%s/%s\" new directory create OK\n",cwd,arg);
                send(client_info.client_fd,msg, strlen(msg),0);
            }else{
                char *send_msg = "550 create directory fail\n";
                send(client_info.client_fd,send_msg, strlen(send_msg),0);
            }
        }
        printf("%s run mkdir finish\n", client_info.user_name);
    }
}
void rnfr(char * arg){
    if(client_info.is_login != 1){
        char *send_msg = "530 no login\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }else{
        printf("%s  start run rnfr\n", client_info.user_name);
        strcpy(src_file_name,arg);
        char *send_msg = "350 get src file name\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
        printf("%s run rnfr finish\n", client_info.user_name);
    }
}
void rnto(char * arg){
    if(client_info.is_login != 1){
        char *send_msg = "530 no login\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }else{
        printf("%s  start run rnto\n", client_info.user_name);
        if ( 0 == rename(src_file_name, arg) ) {
             char *send_msg = "250 file name rename success\n";
            send(client_info.client_fd,send_msg, strlen(send_msg),0);
        }else{
            char *send_msg = "501 file name rename fail\n";
            send(client_info.client_fd,send_msg, strlen(send_msg),0);
        }
        printf("%s run rnto finish\n", client_info.user_name);
    }
}
//下载
void retr(char * arg){
    if(client_info.is_login != 1){
        char *send_msg = "530 no login\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }else{
        int fd;//文件描述符
        //检查文件是否可以访问
        if((fd = open(arg,O_RDONLY))< 0 || access(arg, R_OK) != 0){
            char *send_msg = "550 file can't access or open\n";
            send(client_info.client_fd,send_msg, strlen(send_msg),0);
            close(fd);
            return;
        }
        int data_channel_fd;
        char *send_msg = NULL;
        if(pasv_on == 1){
		    struct sockaddr_in ip_addr;
    		int length = sizeof(struct sockaddr_in);
        	if((client_fd_pasv = accept(pasv_data_connection,(struct sockaddr*) &ip_addr,&length))<0)
		    {
		        perror( "client connect failed!!!\n");
		        exit(-1);
		    }
		    client_ip = inet_ntoa(ip_addr.sin_addr);
		    client_info.passive_port = ntohs(ip_addr.sin_port);
		    //响应客户端命令
	        send_msg = "125 data channel OK\n";
	        send(client_info.client_fd,send_msg, strlen(send_msg),0);
	        printf("%s  start run retr\n", client_info.user_name);
	        printf("Passive Mode on\n");
	        printf("client %s on TCP Port %d\n",client_ip,client_info.passive_port);
	        printf("server %s on TCP Port %d\n",server_pasv_ip,server_pasv_port);
	        //服务器端监听
	        data_channel_fd = client_fd_pasv;
        }
        else{
			//建立数据通道
	        data_channel_fd = generate_common_socket(20);
	        struct sockaddr_in data_addr;
	        //内网地址
	        memset(&data_addr, 0, sizeof(data_addr));
	        data_addr.sin_family = AF_INET;
	        data_addr.sin_port = htons(client_info.active_port);
	        data_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	        //连接客户端
	        if(connect(data_channel_fd, (struct sockaddr *)&data_addr, sizeof(struct sockaddr_in)) < 0 )
	        {
	            char *send_msg = "530 connecting to client fail\n";
	            send(client_info.client_fd,send_msg, strlen(send_msg),0);
	            close(fd);
	            return;
	        }
	        //响应客户端命令
	        send_msg = "125 data channel OK\n";
	        send(client_info.client_fd,send_msg, strlen(send_msg),0);
	        printf("%s  start run retr\n", client_info.user_name);
	        printf("Active Mode on\n");
	        printf("Connect client %s on TCP Port %d\n",client_ip,client_info.active_port);
	        printf("server %s on TCP Port %d\n","127.0.0.1",20);
        }
        if (client_info.authority == 1) {
        	printf("speed limit mode.\n");
        	speed_limit_download(arg, data_channel_fd, fd);
        }
        else {
        	 //获得文件信息
	        struct stat stat_buf;
	        fstat(fd, &stat_buf);
	        //计算下载时间
	        struct timeval begin_time;
	        struct timeval end_time;
	        double total_time;
	        gettimeofday(&begin_time,NULL);
	        char data_buf[FILE_BUF_LEN];
	        int read_size;
	        int send_file_size =0;
	        while((read_size = read(fd, data_buf, FILE_BUF_LEN))>0){
	            send_file_size += send(data_channel_fd, data_buf, read_size,0);
	        }
	        send_msg = "226 send file OK\n";
	        send(client_info.client_fd,send_msg, strlen(send_msg),0);
	        gettimeofday(&end_time,NULL);
	        total_time = end_time.tv_sec - begin_time.tv_sec + (double)(end_time.tv_usec - begin_time.tv_usec)/1000000;
	        client_info.traffic += send_file_size;
	        double tranfer_speed = send_file_size/1024/total_time;
	        fprintf(stdout,"%d bytes sended in %0.2f secs (%0.1f KB/s)，all transfer traffic=%d bytes\n",
	            send_file_size, total_time, tranfer_speed, client_info.traffic);
	        close(fd);
	        close(data_channel_fd);
	        printf("%s  run retr finish\n", client_info.user_name);
        }
    }
}
//上传
void stor(char * arg){
    if(client_info.is_login != 1){
        char *send_msg = "530 no login\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }else{
    	int data_channel_fd;
        char *send_msg = NULL;
        if(pasv_on == 1){
        	struct sockaddr_in ip_addr;
    		int length = sizeof(struct sockaddr_in);
        	if((client_fd_pasv = accept(pasv_data_connection,(struct sockaddr*) &ip_addr,&length))<0)
		    {
		        perror( "client connect failed!!!\n");
		        exit(-1);
		    }
		    client_ip = inet_ntoa(ip_addr.sin_addr);
		    client_info.passive_port = ntohs(ip_addr.sin_port);
		    //响应客户端命令
	        send_msg = "125 data channel OK\n";
	        send(client_info.client_fd,send_msg, strlen(send_msg),0);
	        printf("%s  start run retr\n", client_info.user_name);
	        printf("Passive Mode on\n");
	        printf("client %s on TCP Port %d\n",client_ip,client_info.passive_port);
	        printf("server %s on TCP Port %d\n",server_pasv_ip,server_pasv_port);
	        //服务器端监听
	        data_channel_fd = client_fd_pasv;
        }
        else {
        	data_channel_fd = generate_common_socket(20);
	        struct sockaddr_in data_addr;
	        //设置地址
	        memset(&data_addr, 0, sizeof(data_addr));
	        data_addr.sin_family = AF_INET;
	        data_addr.sin_port = htons(client_info.active_port);
	        data_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	        if(connect(data_channel_fd, (struct sockaddr *)&data_addr, sizeof(data_addr)) < 0 )
	        {   
	            //连接失败，就退出
	            char *send_msg = "530 connecting to client fail\n";
	            send(client_info.client_fd,send_msg, strlen(send_msg),0);
	            return;
	        }
	        printf("%s  execute stor\n", client_info.user_name);
	        printf("Active Mode on\n");
	        printf("Connect client %s on TCP Port %d\n",client_ip,client_info.active_port);
	        printf("server %s on TCP Port %d\n","127.0.0.1",20);
	        //响应
	        char * send_msg = "125 data channel OK\n";
	        send(client_info.client_fd,send_msg, strlen(send_msg),0);
        }
        if (client_info.authority == 1) {
        	printf("speed limit mode.\n");
        	speed_limit_upload(arg, data_channel_fd);
        }
        else {
        	//打开文件
	        FILE* fp = fopen(arg,"w");
	        //计算下载时间
	        struct timeval begin_time;
	        struct timeval end_time;
	        double total_time;
	        gettimeofday(&begin_time,NULL);
	        char data_buf[FILE_BUF_LEN];
	        bzero(data_buf, FILE_BUF_LEN);
	        int total_recv_size = 0;
	        int recv_size;
	        while((recv_size = read(data_channel_fd, data_buf, FILE_BUF_LEN))>0){
	            int len = fwrite(data_buf, sizeof(char), recv_size,fp);
	            total_recv_size += recv_size;
	            bzero(data_buf, FILE_BUF_LEN);
	        }
	        send_msg = "226 recv file OK\n";
	        send(client_info.client_fd,send_msg, strlen(send_msg),0);
	        gettimeofday(&end_time,NULL);
	        total_time = end_time.tv_sec - begin_time.tv_sec + (float)(end_time.tv_usec - begin_time.tv_usec)/1000000;
	        client_info.traffic += total_recv_size;
	        double tranfer_speed = total_recv_size/1024/total_time;
	        printf("%d bytes sended in %0.2f secs (%0.1f KB/s)，all transfer traffic=%d bytes\n",
	            total_recv_size, total_time, tranfer_speed, client_info.traffic);
	        close(data_channel_fd);
	        fclose(fp);
	        printf("%s  run retr finish\n", client_info.user_name);
        }
    }
}

void speed_limit_download(char * arg, int data_channel_fd, int fd) {
	 //获得文件信息
    struct stat stat_buf;
    fstat(fd, &stat_buf);
    //计算下载时间
    struct timeval begin_time;
    struct timeval end_time;
    double total_time;
    gettimeofday(&begin_time,NULL);
    char data_buf[FILE_BUF_LEN];
    int read_size;
    int send_file_size = 0;

    int packet_min_int = MIN_SPEED*1024;
    int packet_max_int = MAX_SPEED*1024;
    srand((unsigned)time(NULL));
    int packet_limit = rand() % (packet_max_int - packet_min_int + 1) + packet_min_int;\

    while((read_size = read(fd, data_buf, FILE_BUF_LEN))>0){
        struct timeval time1, time2;
    	gettimeofday(&time1,NULL);
    	
    	send_file_size += send(data_channel_fd, data_buf, read_size,0);

    	gettimeofday(&time2,NULL);
    	total_time = time2.tv_sec - time1.tv_sec + (float)(time2.tv_usec - time1.tv_usec)/1000000;

		double rest = 1.0*read_size/packet_limit - total_time;
		if(rest < 0.0) {
			rest = 0.0;
		}
		int int_rest = (int) 1000000 * rest;
		usleep(int_rest);
        bzero(data_buf, FILE_BUF_LEN);
    }

    char* send_msg = "226 send file OK\n";
    send(client_info.client_fd,send_msg, strlen(send_msg),0);
    gettimeofday(&end_time,NULL);
    total_time = end_time.tv_sec - begin_time.tv_sec + (float)(end_time.tv_usec - begin_time.tv_usec)/1000000;
    client_info.traffic += send_file_size;
    double tranfer_speed = (send_file_size/1024.0)/total_time;
    fprintf(stdout,"%d bytes sended in %0.2f secs (%0.1f KB/s)，all transfer traffic=%d bytes\n",
        send_file_size, total_time, tranfer_speed, client_info.traffic);
    close(fd);
    close(data_channel_fd);
    printf("%s  run retr finish\n", client_info.user_name);
}

void speed_limit_upload(char * arg, int data_channel_fd) {
	//打开文件
    FILE* fp = fopen(arg,"w");
    //计算下载时间
    struct timeval begin_time;
    struct timeval end_time1, end_time2;
    double total_time;
    gettimeofday(&begin_time,NULL);
    char data_buf[FILE_BUF_LEN];
    bzero(data_buf, FILE_BUF_LEN);
    int total_recv_size =0;
    int recv_size;
    int count = 0;

	int packet_min_int = MIN_SPEED*1024;
    int packet_max_int = MAX_SPEED*1024;
    srand((unsigned)time(NULL));
    int packet_limit = rand() % (packet_max_int - packet_min_int + 1) + packet_min_int;

    while((recv_size = read(data_channel_fd, data_buf, FILE_BUF_LEN))>0){
    	struct timeval time1, time2;
    	gettimeofday(&time1,NULL);
    	int len = fwrite(data_buf, sizeof(char), recv_size, fp);
    	gettimeofday(&time2,NULL);
    	total_time = time2.tv_sec - time1.tv_sec + (float)(time2.tv_usec - time1.tv_usec)/1000000;

		double rest = 1.0*recv_size/packet_limit - total_time;
		if(rest < 0.0) {
			rest = 0.0;
		}
		int int_rest = (int) 1000000 * rest;
		usleep(int_rest);
        
        total_recv_size += recv_size;
        bzero(data_buf, FILE_BUF_LEN);
    }

    char* send_msg = "226 recv file OK\n";
    send(client_info.client_fd,send_msg, strlen(send_msg),0);
    gettimeofday(&end_time2,NULL);
    total_time = end_time2.tv_sec - begin_time.tv_sec + (float)(end_time2.tv_usec - begin_time.tv_usec)/1000000;
    client_info.traffic += total_recv_size;
    double tranfer_speed = (total_recv_size/1024.0)/total_time;
    printf("%d bytes sended in %0.2f secs (%0.2f KB/s)，all transfer traffic=%d bytes\n",
        total_recv_size, total_time, tranfer_speed, client_info.traffic);
    close(data_channel_fd);
    fclose(fp);
    printf("%s  run retr finish\n", client_info.user_name);
}

void dele(char * arg){
    if(client_info.is_login != 1){
        char *send_msg = "530 no login\n";
        send(client_info.client_fd,send_msg, strlen(send_msg),0);
    }else{
        printf("%s start run dele\n", client_info.user_name);
        if(0 == remove(arg)){
            char *send_msg = "250 dele finish.\n";
            send(client_info.client_fd,send_msg, strlen(send_msg),0);
        }else{
            char *send_msg = "550 File is not exist.\n";
            send(client_info.client_fd,send_msg, strlen(send_msg),0);
        }
        printf("%s start dele finish\n", client_info.user_name);
    }
}